'use strict';

module.exports = [
  { x: 1, y: 2 },
  { x: 0, y: 2 },
  { r: 10 },
  { r: 1 },
  { x: 1, y: 2, r: 10, label: 'center/big' },
  { x: 1, y: 2, r: 10, label: 'center/big' },
  { x: 1, y: 2, r: 10, label: 'center/big' },
  { x: 1, y: 2, r: 10, label: 'center/big' }
];
