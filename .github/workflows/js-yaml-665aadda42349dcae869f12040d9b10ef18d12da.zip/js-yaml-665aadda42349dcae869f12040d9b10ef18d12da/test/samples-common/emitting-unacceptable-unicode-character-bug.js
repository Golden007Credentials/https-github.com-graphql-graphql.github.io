'use strict';

module.exports = '\udd00';
