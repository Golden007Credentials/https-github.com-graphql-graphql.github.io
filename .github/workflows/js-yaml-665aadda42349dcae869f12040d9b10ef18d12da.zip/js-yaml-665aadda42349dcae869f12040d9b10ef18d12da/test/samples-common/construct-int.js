'use strict';

module.exports = {
  canonical: 685230,
  decimal: 685230,
  octal: 685230,
  hexadecimal: 685230,
  binary: 685230,
  sexagesimal: 685230
};
