'use strict';


module.exports = [
  /fo{2,}/,
  /[wv]orlds?/g,
  /^spec/im,
  /ba+r/,
  /ba.z*/gim
];
