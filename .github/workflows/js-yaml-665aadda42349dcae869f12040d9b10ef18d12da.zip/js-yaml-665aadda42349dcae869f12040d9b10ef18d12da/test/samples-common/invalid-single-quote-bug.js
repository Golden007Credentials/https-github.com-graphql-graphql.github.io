'use strict';

module.exports = [
  "foo 'bar'",
  "foo\n'bar'"
];
