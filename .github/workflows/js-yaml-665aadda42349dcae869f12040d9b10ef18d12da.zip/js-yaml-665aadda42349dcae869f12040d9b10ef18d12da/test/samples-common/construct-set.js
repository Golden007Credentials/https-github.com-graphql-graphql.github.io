'use strict';

module.exports = {
  'baseball players': {
    'Mark McGwire': null,
    'Sammy Sosa': null,
    'Ken Griffey': null
  },
  'baseball teams': {
    'Boston Red Sox': null,
    'Detroit Tigers': null,
    'New York Yankees': null
  }
};
