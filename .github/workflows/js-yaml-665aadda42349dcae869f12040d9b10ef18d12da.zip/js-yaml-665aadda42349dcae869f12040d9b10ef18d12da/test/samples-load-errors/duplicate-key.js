'use strict';

module.exports = { foo: 'baz' };
